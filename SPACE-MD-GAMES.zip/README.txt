SPACE-MD Games Pack
------------------

What this adds:
- A 'games' folder with many single-player and simple multiplayer game plugins.
- Each file attempts to auto-register with common bot APIs (client.addCommand, client.register, or Baileys ev listener).
- Default command prefix is '.' (change via environment variable CMD_PREFIX).

How to install:
1. Unzip the 'games' folder into your SPACE-MD root (next to index.js).
2. If your SPACE-MD index automatically loads/executes JS files in the root, these will auto-register. 
   If not, add a single line into your index.js near startup (recommended):
     require('./games/gamesmenu.js')(global.client || global.conn || undefined);
   And for each plugin (optional), call require('./games/rps.js')(global.client || global.conn);
3. Restart your bot.
4. Use commands like: .games, .rps rock, .tictactoe 5, .guessthenumber 42

Notes:
- Some multiplayer games (Ludo, UNO) are placeholders here because full multiplayer implementations are complex.
- If your bot exposes a different API, open one of these files and adapt registerWithClient logic to your API.
